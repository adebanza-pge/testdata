import { OntologyEditFunction, LocalDate, UserFacingError, Filters, Double, Integer, Edits} from "@foundry/functions-api";
import { Objects, EormKeyRiskIndicator, EormKriActualTarget, EormKriAnnualTarget } from "@foundry/ontology-api";

export class editKRIFunctions {

    @Edits(EormKeyRiskIndicator)
    @OntologyEditFunction()
    public editKRI(kri: EormKeyRiskIndicator,
                   validFrom: LocalDate,
                   validUntil: LocalDate,
                   reportingFrequency: string,
                   reporter: string,
                   status: string,
                   kriDescription: string): void {
        const kriObject = kri;

        kriObject.validFrom = validFrom;

        kriObject.validUntil = validUntil;

        if (reportingFrequency === "Annual" || reportingFrequency === "Quarterly" || reportingFrequency === "Monthly"){
            kriObject.rptFreq = reportingFrequency;
        }
        else {
            throw new UserFacingError("Reporting Frequency must be Annual, Quarterly, or Monthly. Not: " + reportingFrequency);
        }
        
        kriObject.reporter = reporter;

        if (status === "Active" || status === "Inactive" || status === "In Development") {
            kriObject.status = status;
        }
        else {
            throw new UserFacingError("Status must be Active, Inactive, or In Development. Not: " + status);
        }

        kriObject.kriDesc = kriDescription;
    }

    @Edits(EormKeyRiskIndicator)
    @OntologyEditFunction()
    public createNewKRI(riskID: string,
                        newKRIName: string,
                        newReporter: string,
                        newStatus: string,
                        newRptFreq: string,
                        newDesc: string,
                        newValidFrom: LocalDate,
                        newValidUntil: LocalDate): void {

        //check if KRI name exists
        const krisWithThisNameAndRisk = Objects.search()
                                               .eormKeyRiskIndicator()
                                               .filter(kri => Filters.and(kri.riskId.exactMatch(riskID),
                                                                          kri.kriName.exactMatch(newKRIName)))
                                               .all();
        
        if (krisWithThisNameAndRisk.length > 0) {
            throw new UserFacingError("A KRI with this name already exists, please choose another.");
        }

        // check if valid status
        if (newStatus !== "Active" && newStatus !== "Inactive" && newStatus !== "In Development") {
            throw new UserFacingError("Status must be Active, Inactive, or In Development. Not: " + newStatus);
        }

        // check if valid reporting frequency
        if (newRptFreq !== "Annual" && newRptFreq !== "Quarterly" && newRptFreq !== "Monthly") {
            throw new UserFacingError("Reporting Frequency must be Annual, Quarterly, or Monthly. Not: " + newRptFreq);
        }
        
        // compute new kri ID
        const krisMatchingRiskID = Objects.search()
                                          .eormKeyRiskIndicator()
                                          .filter(kri => 
                                                  Filters.and(kri.riskId.exactMatch(riskID)))
                                          .all();
        
        var kriIDNumbers: Array<number> = [];
        
        for (var i = 0; i < krisMatchingRiskID.length; i++) {
            var kriID = krisMatchingRiskID[i].kriId;
            var kriIDComponents = kriID.split("-");
            var kriIDNumber = Number(kriIDComponents[kriIDComponents.length - 1]);
            kriIDNumbers.push(kriIDNumber);
        }
        
        const maxNum = Math.max(...kriIDNumbers.map(function(kriN: number) {return kriN;}));
        const newKRIID = riskID + "-" + String(maxNum + 1);

        const newKRI = Objects.create().eormKeyRiskIndicator(newKRIID);
        newKRI.riskId = riskID;
        newKRI.kriName = newKRIName;
        newKRI.kriDesc = newDesc;
        newKRI.reporter = newReporter;
        newKRI.rptFreq = newRptFreq;
        newKRI.status = newStatus;
        newKRI.validFrom = newValidFrom;
        newKRI.validUntil = newValidUntil;
    }

    @Edits(EormKriActualTarget)
    @OntologyEditFunction()
    public submitNewMeasure(
        kriID?: string,
        year?: Integer,
        month?: Integer,
        monthlyTargetValue?: Double,
        monthlyActualValue?: Double,
        ytdTargetValue?: Double,
        ytdActualValue?: Double,
        note?: string): void {
            if (kriID === undefined || year === undefined || month === undefined){
                throw new UserFacingError("KRI ID, Year, and Month much be defined.")
            }
            // Check to see if EormKriActualTarget exists
            const measurementsForKRIYearMonth = Objects.search()
                                                       .eormKriActualTarget()
                                                       .filter(measurement => Filters.and(measurement.kriId.exactMatch(kriID),
                                                                                          measurement.year.exactMatch(year),
                                                                                          measurement.month.exactMatch(month)))
                                                       .all();
            if (measurementsForKRIYearMonth.length > 0){
                throw new UserFacingError("Measurement already exists; editing not yet enabled ")
            }
            else {
                //create new object
                const annualsForKRIYear = Objects.search()
                                                       .eormKriAnnualTarget()
                                                       .filter(annual => Filters.and(annual.kriId.exactMatch(kriID),
                                                                                          annual.year.exactMatch(year)))
                                                       .all();

                // const newPrimary Key to generate the new value
                const measurementsForKRIYear = Objects.search()
                                                  .eormKriActualTarget()
                                                  .filter(measurement => Filters.and(measurement.kriId.exactMatch(kriID),
                                                                                          measurement.year.exactMatch(year)))
                                                  .all();

                if (measurementsForKRIYear.length === 0){
                    var newPrimaryKey = kriID + "-" + year + "-1";
                }
                else {
                    var kriIDNumbers: Array<number> = [];
                    for (var i = 0; i < measurementsForKRIYear.length; i++) {
                        var newKriID = measurementsForKRIYear[i].kriPrimaryKey;
                        var kriIDComponents = newKriID.split("-");
                        var kriIDNumber = Number(kriIDComponents[kriIDComponents.length - 1]);
                        kriIDNumbers.push(kriIDNumber);
                    }

                    var maxNum = Math.max(...kriIDNumbers.map(function(kriN: number) {return kriN;}));
                    var newPrimaryKey = kriID + "-" + year + "-" + String(maxNum + 1);
                }

                const newActualObject = Objects.create().eormKriActualTarget(newPrimaryKey)
                const newTitleKey = "KRI Measurement for " + kriID + " for " + month + "/" + String(year)
                newActualObject.kriTitleKey = newTitleKey
                newActualObject.kriId = kriID
                
                if (year >= 2020 || year <= 2100 && month >= 1 || month <= 12) {
                    newActualObject.year = year;
                    newActualObject.month = month;
                    }
                else {
                    throw new UserFacingError("Year must be between 2020 or 2100 && month must be between 1 - 12");
                }
                
                newActualObject.actualsMonthly = monthlyActualValue;
                newActualObject.targetMonthly = monthlyTargetValue;
                newActualObject.targetYtd = ytdTargetValue;
                newActualObject.actualsYtd = ytdActualValue;
                newActualObject.note = note;

                // to implement: compute RAG status
                // get annual target for this KRI and Year, if none exists, set to null
                // compare RAG thresholds with monthly targets 
                // set RAG status
                if (annualsForKRIYear.length === 0) {
                    newActualObject.statusLabel = "RAG thresholds do not exist or are not configured for this metric."
                }
                else if (annualsForKRIYear.length === 1) {
                    const annualTargetObject: EormKriAnnualTarget = annualsForKRIYear[0];
                    if (annualTargetObject === undefined) {
                        throw new UserFacingError("Linked annual obejct is undefined.")
                    }

                    if (annualTargetObject.thresholdType === undefined || annualTargetObject.greenMin === undefined ||
                        annualTargetObject.greenMax === undefined || annualTargetObject.amberMin === undefined ||
                        annualTargetObject.amberMax === undefined || annualTargetObject.redMin === undefined ||
                        annualTargetObject.redMax === undefined) {
                        newActualObject.statusLabel = "N/A";
                    }
                    else {
                        if (annualTargetObject.thresholdType === "percentage of target" && monthlyTargetValue !== undefined) {
                            var greenMinValue: number = annualTargetObject.greenMin * monthlyTargetValue;
                            var greenMaxValue: number = annualTargetObject.greenMax * monthlyTargetValue;
                            var amberMinValue: number = annualTargetObject.amberMin * monthlyTargetValue;
                            var amberMaxValue: number = annualTargetObject.amberMax * monthlyTargetValue;
                            var redMinValue: number = annualTargetObject.redMin * monthlyTargetValue;
                            var redMaxValue: number = annualTargetObject.redMax * monthlyTargetValue;
                        }
                        else if (annualTargetObject.thresholdType === "unit value") {
                            var greenMinValue: number = annualTargetObject.greenMin;
                            var greenMaxValue: number = annualTargetObject.greenMax;
                            var amberMinValue: number = annualTargetObject.amberMin;
                            var amberMaxValue: number = annualTargetObject.amberMax;
                            var redMinValue: number = annualTargetObject.redMin;
                            var redMaxValue: number = annualTargetObject.redMax;
                        }
                        else {
                            var greenMinValue: number = 0;
                            var greenMaxValue: number = 0;
                            var amberMinValue: number = 0;
                            var amberMaxValue: number = 0;
                            var redMinValue: number = 0;
                            var redMaxValue: number = 0;
                        }

                        if (monthlyActualValue === undefined){
                            newActualObject.statusLabel = "Cannot compute RAG status because monthly actual value does not exist.";
                        }
                        else if ((greenMinValue <= monthlyActualValue) && (monthlyActualValue <= greenMaxValue)) {
                            newActualObject.statusLabel = "green";
                        }
                        else if ((amberMinValue <= monthlyActualValue) && (monthlyActualValue <= amberMaxValue)) {
                            newActualObject.statusLabel = "amber";
                        }
                        else if ((redMinValue <= monthlyActualValue) && (monthlyActualValue <= redMaxValue)) {
                            newActualObject.statusLabel = "red";
                        }
                        else {
                            newActualObject.statusLabel = "RAG thresholds do not exist or value entered out of threshold ranges.";
                        }
                    }
                }
                else {
                    throw new UserFacingError("Metric has more than 1 annual target for this year, cannot create new monthly data.");
                }                
            }
                                    
           
        }
            
    @Edits(EormKriAnnualTarget)
    @OntologyEditFunction()
    public submitNewTarget(
        kriID?: string,
        year?: Integer,
        annualTarget?: Double,
        thresholdType?: string,
        greenMin?: Double,
        greenMax?: Double,
        amberMin?: Double,
        amberMax?: Double,
        redMin?: Double,
        redMax?: Double,
        note?: string): void {
            if (kriID === undefined || year === undefined) {
                throw new UserFacingError("Cannot handle annual target objects without a defined KRI or year.");
            }
            const annualsForKRIYear = Objects.search()
                                             .eormKriAnnualTarget()
                                             .filter(annual => Filters.and(annual.kriId.exactMatch(kriID),
                                                                           annual.year.exactMatch(year)))
                                             .all();
            if (annualsForKRIYear.length > 0){
                throw new UserFacingError("Annual target already exists, editing not yet implemented")
            }
            else {
                // const newPrimary Key to generate the new value
                const annualsForKRI = Objects.search()
                                                       .eormKriAnnualTarget()
                                                       .filter(annual => Filters.and(annual.kriId.exactMatch(kriID)))
                                                       .all();
                if (annualsForKRI.length === 0){
                    var newPrimaryKey: string = kriID + "-" + year + "-1";
                }
                else {
                    var kriIDNumbers: Array<number> = [];
                    for (var i = 0; i < annualsForKRI.length; i++) {
                        var newKriID = annualsForKRI[i].kriPrimaryKey;
                        var kriIDComponents = newKriID.split("-");
                        var kriIDNumber = Number(kriIDComponents[kriIDComponents.length - 1]);
                        kriIDNumbers.push(kriIDNumber);
                    }
                    var maxNum = Math.max(...kriIDNumbers.map(function(kriN: number) {return kriN;}));
                    var newPrimaryKey: string = kriID + "-" + year + "-" + String(maxNum + 1);
                }
                
                //create new object
                const newAnnualObject = Objects.create().eormKriAnnualTarget(newPrimaryKey);
                const newTitleKey = "KRI Annual Target for " + kriID + " for " + String(year);
                newAnnualObject.kriTitleKey = newTitleKey;
                newAnnualObject.kriId = kriID;
                
                if (year >= 2020 || year <= 2100) {
                    newAnnualObject.year = year;
                    }
                else {
                    throw new UserFacingError("Year must be between 2020 or 2100");
                }
                newAnnualObject.eoyTarget = annualTarget;
                newAnnualObject.thresholdType = thresholdType;
                newAnnualObject.greenMin = greenMin;
                newAnnualObject.greenMax = greenMax;
                newAnnualObject.amberMin = amberMin;
                newAnnualObject.amberMax = amberMax;
                newAnnualObject.redMin = redMin;
                newAnnualObject.redMax = redMax;
                newAnnualObject.note = note;
            }
    }
}