def program_cost(input_file):

    # We need to drop feature columns that we don't need
    df = program_cost

    # id_cols are the column names that are to remain in the table, unstacked
    id_cols = [
        "lob-riskid", "program_id", "program", "tranche", "allocation_method", "pvrr_multiplier"
    ]

    # the column_head variables are the desired names for the new
    # columns that will be represented on the final dataframe
    column_head1 = 'year'
    column_head2 = 'amount'
    column_head3 = 'prog_expense_cost_id'
    column_head4 = 'prog_cost_type'
    column_head5 = 'lob'
    column_head6 = 'risk_id'
    column_head7 = 'program_id'
    column_head8 = 'program'
    column_head9 = 'pvvr_multiplier'

    # makes an array called cols for the data inside the columns and an array
    # called dtypes for the type of each cell
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in id_cols))

    # assert all columns are of the same type, if not return error and
    # data cleaning must be performed
    assert len(set(dtypes)) == 1, 'All columns must be of the same type!'

    # explode the cols array into an array of two arrays called kvs
    # the first array is called new_column1 and the values are the name of
    # the column (see lit(C))
    # the second array is called new_column2 and the values are the column
    # values from the dataframe (see lit(c))
    kvs = F.explode(F.array([F.struct(F.lit(c).alias(column_head4),
                                      F.col(c).alias(column_head2)) for c in cols])).alias('kvs')

    # re-assign the dataframe as a new dataframe comprised of the original
    # keep columns and the two new, stacked columns
    df = df.select(id_cols + [kvs]).select(id_cols +
                                           ['kvs.'+column_head4, 'kvs.'+column_head2])

    # take the returning dataframe and append the 3 desired rows listed in the
    # 'column_head variables above in order to obtain the cost type and year,
    # we must parse the column name from the original spreadsheet
    # we split on the '_' and select the first(0) and last(2) from list as the
    # cost type and year respectively
    df = df.withColumn(column_head1, F.split(df[column_head4], '_').getItem(2))\
        .withColumn(column_head4, F.split(df[column_head4], '_').getItem(0))

    df = df.withColumn(column_head5, F.split(df['LOB-RiskID'], '-').getItem(0))\
        .withColumn(column_head6, F.split(df['LOB-RiskID'], '-').getItem(1))

    # determine a list containing the arrangement of the columns to be in the final
    # dataframe
    cols_keep = [column_head5, column_head6, column_head3, column_head7, column_head8, column_head9,
                 column_head4, column_head2, column_head1]

    # concat the cost_id column and shape the dataframe according to cols_keep
    df = df.withColumn(column_head3, F.concat_ws('-', df[column_head4], df[column_head1], df[column_head7]))\
        .select(cols_keep)

    melt_df = df.na.fill(value=0)

    # redundant line added for additional clarity, returns df from function
    return melt_df
