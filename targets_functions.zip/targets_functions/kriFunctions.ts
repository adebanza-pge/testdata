import { Function, OntologyEditFunction, LocalDate, UserFacingError, Filters, Double, Integer, Edits} from "@foundry/functions-api";
import { Objects, ObjectSet, EormKeyRiskIndicator, EormRiskKRI, EormKriActualTarget, EormKriAnnualTarget } from "@foundry/ontology-api";

export class editKRIFunctions {
    @Edits(EormKriActualTarget)
    @Edits(EormKriAnnualTarget)
    @OntologyEditFunction()
    public submitNewMeasure(
        kriID: string,
        year: Integer,
        month: Integer,
        monthlyTargetValue: Double,
        monthlyActualValue: Double,
        ytdTargetValue: Double,
        ytdActualValue: Double): void {

            // Check to see if EormKriActualTarget exists
            const measurementsForKRIYearMonth = Objects.search()
                                                       .eormKriActualTarget()
                                                       .filter(measurement => Filters.and(measurement.kriId.exactMatch(kriID),
                                                                                          measurement.year.exactMatch(year),
                                                                                          measurement.month.exactMatch(month)))
                                                       .all();
            if (measurementsForKRIYearMonth.length > 0){
                throw new UserFacingError("Measurement already exists; editing not yet enabled ")
            }
            else {
                //create new object
                const newPrimaryKey = "" // to do 
                const newActualObject = Objects.create().eormKriActualTarget(newPrimaryKey)
                
                if (year >= 2020 || year <= 2100 && month >= 1 || month <= 12) {
                    newActualObject.year = year;
                    newActualObject.month = month;
                    }
                else {
                    throw new UserFacingError("Year must be between 2020 or 2100 && month must be between 1 - 12");
                }
                
                newActualObject.actualsMonthly = monthlyActualValue;
                newActualObject.targetMonthly = monthlyTargetValue;
                newActualObject.targetYtd = ytdTargetValue;
                newActualObject.actualsYtd = ytdActualValue;

                // to implement: compute Red Amber Green status
                // get annual target for this KRI and Year, if none exists, set to null
                // compare RAG thresholds with monthly targets 
                // set RAG status

                // get annual target for this KRI and Year, if none exists, set to null            
                const newAnnualPrimaryKey = ""  // TO DO
                const newAnnualObject = Objects.create().eormKriAnnualTarget(newAnnualPrimaryKey)
                // to implement: compute Red Amber Green status
                var newGreenMin = newAnnualObject.greenMin * newActualObject.actualsMonthly;
                var newGreenMax = newAnnualObject.greenMax * newActualObject.actualsMonthly;
                var newAmberMin = newAnnualObject.amberMin * newActualObject.actualsMonthly;
                var newAmberMax = newAnnualObject.amberMax * newActualObject.actualsMonthly;
                var newRedMin = newAnnualObject.redMin * newActualObject.actualsMonthly;
                var newRedMax = newAnnualObject.redMax * newActualObject.actualsMonthly;

                // set Red Amber Green status
                if (newAnnualObject.thresholdType === "percentage of target"){
                    if ((newGreenMin || newGreenMax) < newAnnualObject.greenMax) {
                        newActualObject.statusLabel = "Green";
                    }
                    if ((newAmberMin || newAmberMax) < newAnnualObject.amberMax){
                        newActualObject.statusLabel = "Amber";
                    }
                    if ((newRedMin || newRedMax) < newAnnualObject.redMax){
                        newActualObject.statusLabel = "Red";
                    }
                }
                if (newAnnualObject.thresholdType === "unit") {
                    if (newAnnualObject.greenMin <= newActualObject.actualsMonthly < newAnnualObject.greenMax){
                        newActualObject.statusLabel = "Green"
                    }
                    if (newAnnualObject.amberMin >= newActualObject.actualsMonthly < newAnnualObject.amberMax){
                        newActualObject.statusLabel = "Amber";
                    }
                    if (newAnnualObject.redMin >= newActualObject.actualsMonthly < newAnnualObject.redMax){
                        newActualObject.statusLabel = "Red";
                    }
                }
            }
            
        }
}